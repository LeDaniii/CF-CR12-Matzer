<!-- blogs site -->
<?php get_header();?>


<div class="container content">
    <?php if (have_posts()): ?>
    <?php while (have_posts()): the_post();?>
    <?php if (has_post_thumbnail()): ?>
    <?php the_post_thumbnail('large');?>
    <?php endif;?>
    <h2><a href="<?php the_permalink();?>"><?php the_title();?></a></h2>
    <p><?php the_time('F j, Y g:i a');?></p>
    <?php the_excerpt();?>
    <?php endwhile;?>
    <?php else: ?>
    <?php__('No Posts found');?>
    <?php endif?>
</div>


<?php get_footer();?>