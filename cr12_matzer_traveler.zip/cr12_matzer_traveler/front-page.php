<?php get_header();?>

<div class=" hero">
    <h1>Everest</h1>
</div>
<div class=" bg-dark text-white text-center">
    <h1 class="py-4 destination">Top Destinations</h1>
</div>
<div class="container-fluid py-4 bg-light">
    <div class="row d-flex justify-content-around">
        <div class="card">
            <img class="card-img-top" src="https://cdn.pixabay.com/photo/2017/01/28/02/24/japan-2014618_960_720.jpg
" alt="Card image cap">
            <div class="card-body">
                <h1>Osaka</h1>
                <p>Some quick example text to build on the card title and make up the bulk of the card's
                    content.</p>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="https://cdn.pixabay.com/photo/2016/11/14/03/19/umbrella-1822478_960_720.jpg
" alt="Card image cap">
            <div class="card-body">
                <h1>Myanmar</h1>
                <p>Some quick example text to build on the card title and make up the bulk of the
                    card's
                    content.</p>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="https://cdn.pixabay.com/photo/2013/06/12/20/52/aso-138984_960_720.jpg
" alt="Card image cap">
            <div class="card-body">
                <h1>Kyushu</h1>
                <p>Some quick example text to build on the card title and make up the bulk of the
                    card's
                    content.</p>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="https://cdn.pixabay.com/photo/2017/11/28/13/08/fishermen-2983615_960_720.jpg
            ">
            <div class="card-body">
                <h1>Vietnam</h1>
                <p>Some quick example text to build on the card title and make up the bulk of the
                    card's
                    content.</p>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="https://cdn.pixabay.com/photo/2016/11/08/05/31/boys-1807545_960_720.jpg
">
            <div class="card-body">
                <h1>Thailand</h1>
                <p>Some quick example text to build on the card title and make up the bulk of the
                    card's
                    content.</p>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="https://cdn.pixabay.com/photo/2016/11/08/05/10/asia-1807504_960_720.jpg
">
            <div class="card-body">
                <h1>Cambodia</h1>
                <p>Some quick example text to build on the card title and make up the bulk of the
                    card's
                    content.</p>
            </div>
        </div>

    </div>
</div>
<?php get_footer();?>