<footer>
    <div class="container-fluid">
        <div class="row bg-dark text-white d-flex justify-content-around">
            <?php if (is_active_sidebar('sidebar')):
    dynamic_sidebar('footer-widget');
endif;
?>
        </div>
    </div>
</footer>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.slim.min.js"></script>
<?php wp_footer();?>

<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js"></script> -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js"></script> -->
</body>

</html>